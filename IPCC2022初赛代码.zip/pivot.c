#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<sys/time.h>
#include<omp.h>
#include<mpi.h>
#include<immintrin.h>

// Calculate sum of distance while combining different pivots. Complexity : O( n^2 )
double SumDistance(const int k, const int n, const int dim, double* coord, int* pivots){
    float* rebuiltCoord = (float*)malloc(sizeof(float) * n * k);
    int i;
    int ki;
    for(ki=0; ki<k; ki++){
        int pivoti = pivots[ki];
        double di[dim];
      for(i=0;i<dim;i++)
            di[i]=coord[pivoti*dim + i];
       __m256d di1,coord1,distance,result;
        for(i=0; i<n-3; i+=4){
            distance=_mm256_setzero_pd();
            int j;
	  
	for(j=0;j<dim;j++)
	{
		di1=_mm256_set1_pd(di[j]);
		coord1=_mm256_set_pd(coord[i*dim + j],coord[(i+1)*dim + j],coord[(i+2)*dim + j],coord[(i+3)*dim + j]);
		result=_mm256_sub_pd(di1,coord1);
		result=_mm256_mul_pd(result,result);
		distance=_mm256_add_pd(distance,result);
	}
		distance=_mm256_sqrt_pd(distance);
		rebuiltCoord[ki*n + i] = distance[0];
                rebuiltCoord[ki*n + i+1] = distance[1];
                rebuiltCoord[ki*n + i+2] = distance[2];
                rebuiltCoord[ki*n + i+3] = distance[3];
        }
	for(i=i; i<n; i++){
            double distance = 0;
            int j;
            for(j=0; j<dim; j++){
                distance += pow(di[j]- coord[i*dim + j] ,2);
            }
            rebuiltCoord[i*k + ki] = sqrt(distance);
        }	
    }
/*	int ki;
        for(ki=0; ki<k; ki++){
        int pivoti = pivots[ki];
        float di[dim];
      for(i=0;i<dim;i++)
            di[i]=coord[pivoti*dim + i];
	__m256 di1,coord1,distance,result;
        for(i=0; i<n-7; i+=8){
            distance=_mm256_setzero_ps();
            int j;
	for(j=0;j<dim;j++)
        {
                di1=_mm256_set1_ps(di[j]);
                coord1=_mm256_set_ps(coord[i*dim + j],coord[(i+1)*dim + j],coord[(i+2)*dim + j],coord[(i+3)*dim + j],
					coord[(i+4)*dim + j],coord[(i+5)*dim + j],coord[(i+6)*dim + j],coord[(i+7)*dim + j]);
                result=_mm256_sub_ps(di1,coord1);
                result=_mm256_mul_ps(result,result);
                distance=_mm256_add_ps(distance,result);
  	}
                distance=_mm256_sqrt_ps(distance);
		_mm256_store_ps(&rebuiltCoord[ki*n + i],distance);
		rebuiltCoord[ki*n + i] = distance[0];
                rebuiltCoord[ki*n + i+1] = distance[1];
                rebuiltCoord[ki*n + i+2] = distance[2];
                rebuiltCoord[ki*n + i+3] = distance[3];
		rebuiltCoord[ki*n + i+4] = distance[4];
                rebuiltCoord[ki*n + i+5] = distance[5];
                rebuiltCoord[ki*n + i+6] = distance[6];
                rebuiltCoord[ki*n + i+7] = distance[7];	
        }
        for(i=i; i<n; i++){
            float distance = 0;
            int j;
            for(j=0; j<dim; j++){
                distance += pow(di[j]- coord[i*dim + j] ,2);
            }
            rebuiltCoord[i*k + ki] = sqrt(distance);
        }       
    }
*/
    // Calculate the sum of Chebyshev distance with rebuilt coordinates between every points
    double chebyshevSum=0; 
__m256 temp,temp2,coordi,coordj,result1,result2,c,c2,result11,result22,coordi2,coordj2;
     for(i=0; i<n; i++){
        int j;
	float di[k];
	temp=_mm256_setzero_ps();
	for(j=0;j<k;j++)
		di[j]=rebuiltCoord[j*n+i];
		for(j=i+1; j<n-7; j+=8){
 			result1=_mm256_setzero_ps();          
                for(ki=0; ki<k; ki++){
                        coordi=_mm256_set1_ps(di[ki]);
                        coordj=_mm256_load_ps(&rebuiltCoord[ki*n+j]);
                        result2=_mm256_sub_ps(coordi,coordj);
                        c=_mm256_setzero_ps();
                        c=_mm256_sub_ps(c,result2);
                        result2=_mm256_max_ps(c,result2);
                        result1=_mm256_max_ps(result1,result2);
                        }
                 temp=_mm256_add_ps(temp,result1);
                }
		
		chebyshevSum+=temp[0]+temp[1]+temp[2]+temp[3]+temp[4]+temp[5]+temp[6]+temp[7];
		
 		 for(j=j;j<n;j++)
        	{
                float chebyshev=0;
                for(ki=0; ki<k; ki++){
                float dis =fabs(rebuiltCoord[ki*n+i] - rebuiltCoord[ki*n + j]);
                chebyshev = dis>chebyshev ? dis : chebyshev;
            	}
                chebyshevSum += chebyshev;

      }
	
}
    free(rebuiltCoord);

    return chebyshevSum;
}

// Recursive function Combination() : combine pivots and calculate the sum of distance while combining different pivots.
// ki  : current depth of the recursion
// k   : number of pivots
// n   : number of points
// dim : dimension of metric space
// M   : number of combinations to store
// coord  : coordinates of points
// pivots : indexes of pivots
// maxDistanceSum  : the largest M distance sum
// maxDisSumPivots : the top M pivots combinations
// minDistanceSum  : the smallest M distance sum
// minDisSumPivots : the bottom M pivots combinations
void Combination(int ki, const int k, const int n, const int dim, const int M, double* coord, int* pivots,
                 double* maxDistanceSum, int* maxDisSumPivots, double* minDistanceSum, int* minDisSumPivots,int threads){
    if(ki==k-1){
        int i;
	int begin=pivots[ki-1]+1;
        double number[n-begin];
	#pragma omp parallel for num_threads(threads)	
	for(i=0;i<n-begin;i++)
	{
		int pi[k];
		int j;
		for(j=0;j<ki;j++)
		pi[j]=pivots[j];
		pi[ki]=i+begin;
	number[i]= SumDistance(k, n, dim, coord, pi);
	}
	for(i=begin; i<n; i++){
            pivots[ki] = i;
            double distanceSum =number[i-begin];
            maxDistanceSum[M] = distanceSum;
	    minDistanceSum[M] = distanceSum;

            int kj;
            for(kj=0; kj<k; kj++){
                maxDisSumPivots[M*k + kj] = pivots[kj];
            }

	    for(kj=0; kj<k; kj++){
                minDisSumPivots[M*k + kj] = pivots[kj];
            }
       
            int a;
            for(a=M; a>0; a--){
                if(maxDistanceSum[a] > maxDistanceSum[a-1]){
                    double temp = maxDistanceSum[a];
                    maxDistanceSum[a] = maxDistanceSum[a-1];
                    maxDistanceSum[a-1] = temp;
                    int kj;
                    for(kj=0; kj<k; kj++){
                        int temp = maxDisSumPivots[a*k + kj];
                        maxDisSumPivots[a*k + kj] = maxDisSumPivots[(a-1)*k + kj];
                        maxDisSumPivots[(a-1)*k + kj] = temp;
                    }
                }
		else 
			break;
            }

            for(a=M; a>0; a--){
                if(minDistanceSum[a] < minDistanceSum[a-1]){
                    double temp = minDistanceSum[a];
                    minDistanceSum[a] = minDistanceSum[a-1];
                    minDistanceSum[a-1] = temp;
                    int kj;
                    for(kj=0; kj<k; kj++){
                        int temp = minDisSumPivots[a*k + kj];
                        minDisSumPivots[a*k + kj] = minDisSumPivots[(a-1)*k + kj];
                        minDisSumPivots[(a-1)*k + kj] = temp;
                    }
                }
		else 
			break;
            }
        }
        return;
    }

    // Recursively call Combination() to combine pivots
    int i;
    for(i=pivots[ki-1]+1; i<n; i++) {
        pivots[ki] = i;
        Combination(ki+1, k, n, dim, M, coord, pivots, maxDistanceSum, maxDisSumPivots, minDistanceSum, minDisSumPivots,threads);
    }
}

        void Combination2(const int size,const int id ,const int k, const int n, const int dim, const int M, double* coord, int* pivots,double* maxDistanceSum, int* maxDisSumPivots, double* minDistanceSum, int* minDisSumPivots,int threads)
{
	int i;
  	for(i=id; i<n; i+=size) 
	{        
		pivots[0] = i;        
	 Combination(1, k, n, dim, M, coord, pivots, maxDistanceSum, maxDisSumPivots, minDistanceSum, minDisSumPivots,threads);
	}	 
}
	void sort(const int size,const int n,const int k,const int M, double* maxDistanceSum, int* maxDisSumPivots, double* minDistanceSum,int* minDisSumPivots,double* maxDistanceSum1, int* maxDisSumPivots1, double* minDistanceSum1, int* minDisSumPivots1)
{

	int i;
	int ii=0;	
 	for(i=0;i<M;i++)
	{
		minDistanceSum[M]=minDistanceSum1[i];
		int kj;
		for(kj=0; kj<k; kj++){
	                minDisSumPivots[M*k + kj] = minDisSumPivots1[i*k+kj];
		}
		for(ii=M;ii>0;ii--)
		{	
		  if(minDistanceSum[ii] < minDistanceSum[ii-1]){
                    double temp = minDistanceSum[ii];
                    minDistanceSum[ii] = minDistanceSum[ii-1];
                    minDistanceSum[ii-1] = temp;
                 
                    for(kj=0; kj<k; kj++){
                        int temp = minDisSumPivots[ii*k + kj];
                        minDisSumPivots[ii*k + kj] = minDisSumPivots[(ii-1)*k + kj];
                        minDisSumPivots[(ii-1)*k + kj] = temp;
                    }
                }	
		}
	}
	for(i=0;i<M;i++)
        {
                maxDistanceSum[M]=maxDistanceSum1[i];
                int kj;
                for(kj=0; kj<k; kj++){
                        maxDisSumPivots[M*k + kj] = maxDisSumPivots1[i*k+kj];
                }
                for(ii=M;ii>0;ii--)
                {       
                  if(maxDistanceSum[ii] > maxDistanceSum[ii-1]){
                    double temp = maxDistanceSum[ii];
                    maxDistanceSum[ii] = maxDistanceSum[ii-1];
                    maxDistanceSum[ii-1] = temp;

                    for(kj=0; kj<k; kj++){
                        int temp = maxDisSumPivots[ii*k + kj];
                        maxDisSumPivots[ii*k + kj] = maxDisSumPivots[(ii-1)*k + kj];
                        maxDisSumPivots[(ii-1)*k + kj] = temp;
                    }
                }
                }
        }     
}

int main(int argc, char* argv[]){

    // filename : input file namespace
    char* filename = (char*)"uniformvector-2dim-5h.txt";
    if( argc==2 ) {
        filename = argv[1];
    }  else if(argc != 1) {
        printf("Usage: ./pivot <filename>\n");
        return -1;
    }
    // M : number of combinations to store
    const int M = 1000;
    // dim : dimension of metric space
    int dim;
    // n : number of points
    int n;
    // k : number of pivots
    int k;

    // Read parameter
    FILE* file = fopen(filename, "r");
    if( file == NULL ) {
        printf("%s file not found.\n", filename);
        return -1;
    }
    fscanf(file, "%d", &dim);
    fscanf(file, "%d", &n);
    fscanf(file, "%d", &k);
    printf("dim = %d, n = %d, k = %d\n", dim, n, k);

    // Start timing
    struct timeval start,stop,start1,end1;

    // Read Data
    double* coord = (double*)malloc(sizeof(double) * dim * n);
    int i;
    for(i=0; i<n; i++){
        int j;
        for(j=0; j<dim; j++){
            fscanf(file, "%lf", &coord[i*dim + j]);
        }
    }
    fclose(file);
gettimeofday(&start, NULL);
	int threads=k<3? 32:24;

    double* maxDistanceSum = (double*)malloc(sizeof(double) * (M+1));
    for(i=0; i<M; i++){
        maxDistanceSum[i] = 0;
    }
 
    int* maxDisSumPivots = (int*)malloc(sizeof(int) * k * (M+1));
 /*   for(i=0; i<M; i++){
        int ki;
        for(ki=0; ki<k; ki++){
            maxDisSumPivots[i*k + ki] = 0;
        }
    }*/
 
    double* minDistanceSum = (double*)malloc(sizeof(double) * (M+1));
    for(i=0; i<M; i++){
        minDistanceSum[i] = __DBL_MAX__;
    }
  
    int* minDisSumPivots = (int*)malloc(sizeof(int) * k * (M+1));
    /*for(i=0; i<M; i++){
        int ki;
        for(ki=0; ki<k; ki++){
            minDisSumPivots[i*k + ki] = 0;
        }
    }*/

    int* temp = (int*)malloc(sizeof(int) * (k+1));
    temp[0] = -1;
//MPI_INIT 
    int id,size;
    MPI_Status status;
    MPI_Init(&argc,&argv);
    MPI_Comm_rank(MPI_COMM_WORLD,&id);
    MPI_Comm_size(MPI_COMM_WORLD,&size);

//MPI_worlk
Combination2(size,id,k, n, dim, M, coord, &temp[1], maxDistanceSum, maxDisSumPivots, minDistanceSum, minDisSumPivots,threads);

//通信缓冲
	double* maxDistanceSum1 = (double*)malloc(sizeof(double) *(M+1));
        int* maxDisSumPivots1 = (int*)malloc(sizeof(int) * k * (1+M));
        double* minDistanceSum1 = (double*)malloc(sizeof(double) * (M+1));
        int* minDisSumPivots1 = (int*)malloc(sizeof(int) * k * (M+1));
if(id!=0)
{
    MPI_Send(maxDistanceSum,M,MPI_DOUBLE,0,id,MPI_COMM_WORLD);
    MPI_Send(minDistanceSum,M,MPI_DOUBLE,0,id,MPI_COMM_WORLD);
    MPI_Send(maxDisSumPivots,k*M,MPI_INT,0,id,MPI_COMM_WORLD);
    MPI_Send(minDisSumPivots,k*M,MPI_INT,0,id,MPI_COMM_WORLD);

}
else
{
	int ids=0;
    for(ids=1;ids<size;ids++)
   {
	
	MPI_Recv(maxDistanceSum1,M+1,MPI_DOUBLE,ids,ids,MPI_COMM_WORLD,&status);
	MPI_Recv(minDistanceSum1,M+1,MPI_DOUBLE,ids,ids,MPI_COMM_WORLD,&status);
	MPI_Recv(maxDisSumPivots1,k*M+1,MPI_INT,ids,ids,MPI_COMM_WORLD,&status);
	MPI_Recv(minDisSumPivots1,k*M+1,MPI_INT,ids,ids,MPI_COMM_WORLD,&status);

       sort(1,n,k,M,maxDistanceSum, maxDisSumPivots, minDistanceSum, minDisSumPivots,maxDistanceSum1, maxDisSumPivots1, minDistanceSum1, minDisSumPivots1);
    }
}
if(id!=0)
        {
                MPI_Finalize();
                exit(1);
        } 
if(id==0)
{
    // End timing
    struct timeval end;
    gettimeofday (&end, NULL);
    printf("Using time : %f ms\n", (end.tv_sec-start.tv_sec)*1000.0+(end.tv_usec-start.tv_usec)/1000.0);
}    
    // Store the result
    FILE* out = fopen("result.txt", "w");
    for(i=0; i<M; i++){
        int ki;
        for(ki=0; ki<k-1; ki++){
            fprintf(out, "%d ", maxDisSumPivots[i*k + ki]);
        }
        fprintf(out, "%d\n", maxDisSumPivots[i*k + k-1]);
	}
    for(i=0; i<M; i++){
        int ki;
        for(ki=0; ki<k-1; ki++){
            fprintf(out, "%d ", minDisSumPivots[i*k + ki]);
        }
	fprintf(out, "%d\n", minDisSumPivots[i*k + k-1]);
    }
    fclose(out);

    // Log
    int ki;
    printf("max : ");
    for(ki=0; ki<k; ki++){
        printf("%d ", maxDisSumPivots[ki]);
    }
    printf("%lf\n", maxDistanceSum[0]);
    printf("min : ");
    for(ki=0; ki<k; ki++){
        printf("%d ", minDisSumPivots[ki]);
    }
    printf("%lf\n", minDistanceSum[0]);
    return 0;
}
