#!/bin/bash
#SBATCH -p IPCC
###SBATCH -c 32
#SBATCH -N 2
#SBATCH -n 4
##SBATCH --ntasks-per-node=2

source /public1/soft/modules/module.sh

module load mpi/intel/18.2
 
export OMP_NUM_THREADS=32
export OMP_PROC_BIND=true
mpicc -o pivot pivot.c  -O3 -fopenmp -lm -mavx2 -mavx  -static_mpi -unroll-aggressive -lnuma 
numactl --cpunodebind=0,1 mpirun -np 4 ./pivot
